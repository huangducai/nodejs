/**
 * Created by zxh on 16/10/26.
 */
 var _ = require('underscore');
 var fs = require('fs');
 var util = require('util');
 var async = require('async');
 var Path = require('path');

// var ToolsHelper = require('../ToolsHelper.js');
// var client_resource = '../svn/client_tp_res/ios/client_res_pvr';
// var zhuanhuanDir = '../svn/resouter/res';
//
//
// function copy(from, to){
//     ToolsHelper.copyDir(from, to);
// }
//
// copy(zhuanhuanDir, client_resource);




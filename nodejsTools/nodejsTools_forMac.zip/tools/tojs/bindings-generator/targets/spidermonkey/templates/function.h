bool js_${generator.prefix}_${class_name}_${func_name}(JSContext *cx, uint32_t argc, jsval *vp);

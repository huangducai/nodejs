
\#endif // __${prefix}_h__
#if $macro_judgement
\#endif //$macro_judgement
#end if